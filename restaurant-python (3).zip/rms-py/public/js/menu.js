// เมนู วัตถุดิบ ตัวเลือก รูปอาหาร
function vMenu(){return vMenu0()+ingSec()}
function vMenu0(){
 return `<h2>จัดการเมนู</h2>
 <div class="f"><input id="mn" placeholder="ชื่อเมนู"><input id="mc" placeholder="หมวดหมู่"><input id="mp" type="number" placeholder="ราคา"><input id="ms" type="number" placeholder="สต๊อก"><button class="b p" onclick="addMenu()">เพิ่ม</button></div>`
 +S.menu.map(m=>`<div class="card"><div class="row"><div><b>${pic(m)} ${esc(m.name)}</b> ${bs(m)}<div class="m">${esc(m.cat)} · ฿${fmt(m.price)}</div></div>${stockTag(m)}</div>
 <div class="row m" style="margin-top:6px;justify-content:flex-start;gap:14px"><label><input type="checkbox" ${m.sp?'checked':''} onchange="flag(${m.id},'sp',this.checked)"> มีตัวเลือกเผ็ด</label><label><input type="checkbox" ${m.drink?'checked':''} onchange="flag(${m.id},'drink',this.checked)"> เครื่องดื่ม (ความหวาน)</label>${m.drink?`<label><input type="checkbox" ${m.pearl?'checked':''} onchange="flag(${m.id},'pearl',this.checked)"> ไข่มุก</label>`:''}</div>
 <div class="row" style="margin-top:8px"><span class="q">สต๊อก <button class="b" onclick="stk(${m.id},-1)">−</button><b>${m.stock}</b><button class="b" onclick="stk(${m.id},1)">+</button><button class="b" onclick="stk(${m.id},10)">+10</button></span>
 <span><label class="b" style="cursor:pointer">📷 รูป<input type="file" accept="image/*" hidden onchange="upImg(${m.id},this)"></label> <button class="b" onclick="editOpt(${m.id})">ตัวเลือก/สูตร</button> <button class="b" onclick="editMenu(${m.id})">แก้ไข</button> <button class="b d" onclick="delMenu(${m.id})">ลบ</button></span></div></div>`).join('')||'<p class="m">ยังไม่มีเมนู เพิ่มรายการแรกได้ด้านบน</p>';
}
function addMenu(){const n=$('#mn').value.trim(),p=+$('#mp').value;if(!n||!(p>=0))return alert('กรอกชื่อและราคา');
 S.menu.push({id:uid(),name:n,cat:$('#mc').value.trim()||'ทั่วไป',price:p,stock:Math.max(0,+$('#ms').value||0),img:'🍽️',sp:false,drink:false,pearl:false,opts:[],rec:{}});render()}
function stk(id,d){const m=S.menu.find(x=>x.id==id);m.stock=Math.max(0,m.stock+d);render()}
function editMenu(id){const m=S.menu.find(x=>x.id==id);
 const n=prompt('ชื่อเมนู',m.name);if(n===null)return;const p=prompt('ราคา',m.price);const s=prompt('จำนวนสต๊อก (0 = หมด)',m.stock);
 m.name=n||m.name;m.price=+p>=0&&p!==''?+p:m.price;m.stock=Math.max(0,+s||0);render()}
function delMenu(id){if(confirm('ลบเมนูนี้?')){S.menu=S.menu.filter(x=>x.id!=id);render()}}
function choose(mid){const m=S.menu.find(x=>x.id==mid);
 const rg=(nm,ttl,arr,def)=>`<div class="card"><b>${ttl}</b><div class="row" style="justify-content:flex-start;margin-top:6px">`+arr.map(v=>`<label><input type="radio" name="${nm}" value="${v}" ${v==def?'checked':''}> ${v}</label>`).join(' ')+'</div></div>';
 let h=`<div class="row"><h2>${esc(m.name)}</h2><button class="b" onclick="back()">ยกเลิก</button></div>`;
 if(m.sp)h+=rg('sp','ความเผ็ด',['ปกติ','เผ็ดน้อย','เผ็ดมาก'],'ปกติ');
 if(m.drink)h+=rg('sw','ความหวาน',['หวาน 100%','หวาน 75%','หวาน 50%','หวาน 25%','หวาน 0%'],'หวาน 100%');
 const cb=[['พิเศษ',m.spx==null?15:m.spx]];if(m.pearl)cb.push(['ไข่มุก',m.pr==null?10:m.pr]);(m.opts||[]).forEach(o=>cb.push([o.n,o.a]));
 h+=cb.map(([n,a])=>`<label class="card row"><span><input type="checkbox" class="oc" value="${esc(n)}" data-a="${a}"> ${esc(n)}</span><span class="m">${a?'+'+a:'ฟรี'}</span></label>`).join('');
 $('#sh').innerHTML=h+`<button class="b p" style="width:100%" onclick="addOpt(${mid})">เพิ่มลงออเดอร์</button>`;$('#md').classList.add('on')}
function addOpt(mid){const L=[];let x=0;
 ['sp','sw'].forEach(n=>{const r=document.querySelector(`input[name=${n}]:checked`);if(r&&r.value!='ปกติ')L.push(r.value)});
 document.querySelectorAll('.oc:checked').forEach(c=>{L.push(c.value);x+=+c.dataset.a});
 add(mid,{labels:L,extra:x});if(QT)closeM()}
function back(){QT?closeM():tableSheet()}
function upImg(id,inp){const f=inp.files[0];if(!f)return;const im=new Image();im.onload=async()=>{const k=Math.min(1,640/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=im.width*k;c.height=im.height*k;c.getContext('2d').drawImage(im,0,0,c.width,c.height);
 try{const r=await fetch('/api/staff/upload',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+TK},body:JSON.stringify({data:c.toDataURL('image/jpeg',.8)})});const j=await r.json();S.menu.find(x=>x.id==id).photo=j.url;render()}catch(e){alert('อัปโหลดรูปไม่สำเร็จ')}};im.src=URL.createObjectURL(f)}
function flag(id,k,v){S.menu.find(x=>x.id==id)[k]=v;render()}
function editOpt(id){const m=S.menu.find(x=>x.id==id);const sx=prompt('ราคา "พิเศษ" เพิ่มกี่บาท',m.spx==null?15:m.spx);if(sx===null)return;m.spx=+sx||0;if(m.pearl){const pr=prompt('ราคาไข่มุกเพิ่มกี่บาท',m.pr==null?10:m.pr);if(pr!==null)m.pr=+pr||0}
 const o=prompt('ตัวเลือกเมนู รูปแบบ ชื่อ:ราคาเพิ่ม คั่นด้วย , (เช่น ไข่ดาว:10,เผ็ดมาก:0)',m.opts.map(x=>x.n+':'+x.a).join(','));if(o===null)return;
 const r=prompt('สูตรตัดสต็อกวัตถุดิบ รูปแบบ วัตถุดิบ:ปริมาณ (เช่น หมูสับ:1)',Object.entries(m.rec).map(([k,v])=>k+':'+v).join(','));if(r===null)return;
 m.opts=o.split(',').filter(x=>x.trim()).map(x=>{const [n,a]=x.split(':');return{n:n.trim(),a:+a||0}});
 m.rec={};r.split(',').filter(x=>x.trim()).forEach(x=>{const [k,v]=x.split(':');m.rec[k.trim()]=+v||1});render()}
function ingSec(){return `<h2 style="margin-top:20px">วัตถุดิบ</h2><p class="m">ตัดสต็อกตามสูตรของเมนูอัตโนมัติ ถ้าวัตถุดิบไม่พอเมนูจะขึ้นหมด</p>`+S.ings.map(g=>`<div class="card"><div class="row"><span><b>${esc(g.name)}</b> <span class="m">เหลือ ${fmt(g.qty)} ${esc(g.u)}</span></span><span class="q"><button class="b" onclick="ig(${g.id},-1)">−</button><button class="b" onclick="ig(${g.id},10)">+10</button><button class="b d" onclick="ig(${g.id},0)">ลบ</button></span></div></div>`).join('')+`<button class="b" onclick="addIng()">+ เพิ่มวัตถุดิบ</button>`}
function ig(id,d){if(d==0)S.ings=S.ings.filter(x=>x.id!=id);else{const g=S.ings.find(x=>x.id==id);g.qty=Math.max(0,g.qty+d)}render()}
function addIng(){const n=prompt('ชื่อวัตถุดิบ');if(!n)return;S.ings.push({id:uid(),name:n.trim(),qty:+prompt('จำนวนคงเหลือ','20')||0,u:prompt('หน่วย','หน่วย')||'หน่วย'});render()}
