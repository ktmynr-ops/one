// จุดเริ่มต้น: แยกทางเข้าพนักงาน / ลูกค้า
if(MODE=='cust'){if(QT&&QK)start();else custError()}
else{if(TK)start();else login()}
