// จองโต๊ะ / คิว
function vQueue(){return `<h2>จองโต๊ะ / คิว</h2><div class="f"><input id="qn" placeholder="ชื่อ"><input id="qg" type="number" placeholder="กี่ท่าน"><select id="qk"><option>คิว</option><option>จอง</option></select><input id="qt" placeholder="เวลา เช่น 18:30"><button class="b p" onclick="addQ()">เพิ่ม</button></div>`
 +(S.queue.map(q=>`<div class="card"><div class="row"><div><b>${q.k} #${q.no} ${esc(q.n)}</b><div class="m">👥 ${q.g} ท่าน${q.t?' · '+esc(q.t):''}</div></div><span><button class="b p" onclick="seat(${q.id})">จัดโต๊ะ</button> <button class="b d" onclick="dq(${q.id})">ลบ</button></span></div></div>`).join('')||'<p class="m">ยังไม่มีคิวหรือการจอง</p>')}
function addQ(){const n=$('#qn').value.trim(),g=+$('#qg').value;if(!n||!(g>0))return alert('กรอกชื่อและจำนวนท่าน');S.qn=(S.qn||0)+1;S.queue.push({id:uid(),no:S.qn,n,g,k:$('#qk').value,t:$('#qt').value.trim()});render()}
function dq(id){S.queue=S.queue.filter(x=>x.id!=id);render()}
function seat(id){const q=S.queue.find(x=>x.id==id),f=S.tables.filter(t=>t.status=='free'&&t.seats>=q.g);
 if(!f.length)return alert('ไม่มีโต๊ะว่างที่นั่งได้ '+q.g+' ท่าน');
 const to=prompt('เลือกโต๊ะ: '+f.map(t=>t.id+' ('+t.seats+' ที่)').join(', '),f[0].id),t=f.find(x=>x.id==+to);if(!t)return;
 t.guests=q.g;t.status='busy';S.queue=S.queue.filter(x=>x.id!=id);S.tab='tables';render();openTable(t.id)}
