// แกนกลาง: state, ตัวช่วย, render
const $=s=>document.querySelector(s);
const hm=t=>new Date(t).toLocaleTimeString('th-TH',{hour:'2-digit',minute:'2-digit'});
const fmt=n=>n.toLocaleString('th-TH',{minimumFractionDigits:0,maximumFractionDigits:2});
let S;
const seed={menu:[
 {id:1,name:'ผัดกะเพราหมูสับ',cat:'จานเดียว',price:60,stock:20,img:'🍛',sp:true,drink:false,pearl:false,opts:[{n:'ไข่ดาว',a:10}],rec:{'หมูสับ':1,'ข้าวสวย':1}},
 {id:2,name:'ต้มยำกุ้ง',cat:'ต้ม/แกง',price:150,stock:8,img:'🍲',sp:true},
 {id:3,name:'ส้มตำไทย',cat:'ยำ/ตำ',price:50,stock:15,img:'🥗',sp:true},
 {id:4,name:'ชาเย็น',cat:'เครื่องดื่ม',price:35,stock:30,img:'🧋',sp:false,drink:true,pearl:true,opts:[{n:'ไซส์ใหญ่',a:10}],rec:{}}],
 tables:[1,2,3,4,5,6,7,8].map(i=>({id:i,status:'free',items:[],seats:[2,2,4,4,4,6,6,8][i-1],guests:0})),ings:[{id:1,name:'หมูสับ',qty:50,u:'จาน'},{id:2,name:'ข้าวสวย',qty:60,u:'จาน'}],queue:[],members:[],
 sales:[],nid:10,tab:'tables',view:'plan',edit:false,open:null,cfg:{disc:0,vat:7,svc:10}};
try{S=JSON.parse(localStorage.getItem('rms'))||seed}catch(e){S=seed}
S.view=S.view||'plan';S.edit=false;S.ings=S.ings||[];S.queue=S.queue||[];S.members=S.members||[];S.tables.forEach(t=>{t.seats=t.seats||4;t.guests=t.guests||0});S.menu.forEach(m=>{m.opts=(m.opts||[]).filter(o=>!['พิเศษ','เผ็ดมาก','เผ็ดน้อย','หวานน้อย'].includes(o.n));m.rec=m.rec||{};if(m.drink==null)m.drink=/ชา|กาแฟ|น้ำ|นม|โกโก้|โซดา|เครื่องดื่ม/.test(m.name+m.cat);if(m.sp==null)m.sp=!m.drink&&/กะเพรา|ต้มยำ|ตำ|ยำ|ผัด|แกง|ลาบ|น้ำตก|พริก/.test(m.name);if(m.pearl==null)m.pearl=m.drink&&/ชา|นม|โกโก้/.test(m.name)});
function go(t){S.tab=t;render()}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
const ST={free:['ว่าง','ok'],busy:['มีลูกค้า','out'],bill:['รอเช็คบิล','wt']};
const KS={wait:'รอทำ',cook:'กำลังทำ',done:'เสร็จแล้ว'};
function stockTag(m){return m.stock<=0||!can(m,1)?'<span class="tag out">หมด</span>':`<span class="tag ok">เหลือ ${m.stock}</span>`}
function render(){
 if(QT)return cust();
 const tabs=[['menu','เมนู'],['tables','โต๊ะ'],['kitchen','ครัว'],['queue','คิว'],['report','รายงาน']];
 $('#nav').innerHTML=tabs.map(([k,v])=>`<button class="${S.tab==k?'on':''}" onclick="go('${k}')">${v}</button>`).join('');
 $('#app').innerHTML=({menu:vMenu,tables:vTables,kitchen:vKitchen,queue:vQueue,report:vReport})[S.tab]();
 save();
}
function bestIds(){const c={};
 S.sales.forEach(s=>s.items.forEach(i=>c[i.name]=(c[i.name]||0)+i.qty));
 S.tables.forEach(t=>t.items.forEach(i=>{if(!i.cx)c[i.base||i.name]=(c[i.base||i.name]||0)+i.qty}));
 return Object.entries(c).sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>x[0])}
function bs(m){return bestIds().includes(m.name)?'<span class="bs">⭐ Best Seller</span>':''}
function menuSorted(){const b=bestIds();return [...S.menu].sort((x,y)=>(b.includes(y.name)-b.includes(x.name))||(b.indexOf(x.name)-b.indexOf(y.name)))}
const T=()=>S.tables.find(t=>t.id==S.open);
function closeM(){$('#md').classList.remove('on');render()}
function calc(t,disc){const sub=t.items.filter(i=>!i.cx).reduce((a,i)=>a+i.price*i.qty,0);
 const d=Math.min(sub,sub*(disc/100));const svc=(sub-d)*S.cfg.svc/100;const vat=(sub-d+svc)*S.cfg.vat/100;
 return{sub,d,svc,vat,tot:sub-d+svc+vat}}
const MODE=window.RMS_MODE||'staff',QP=new URLSearchParams(location.search),QT=MODE=='cust'?QP.get('table'):null,QK=QP.get('k')||'';if(QT)S.open=+QT;
function refresh(){QT?cust():tableSheet()}
function can(m,n){return Object.entries(m.rec||{}).every(([k,q])=>{const g=S.ings.find(x=>x.name==k);return !g||g.qty>=q*n})}
function use(m,n){Object.entries(m.rec||{}).forEach(([k,q])=>{const g=S.ings.find(x=>x.name==k);if(g)g.qty-=q*n})}
function pic(m){return m.photo?`<img src="${m.photo}" alt="" style="width:46px;height:46px;object-fit:cover;border-radius:8px;vertical-align:middle">`:m.img}
function uid(){return Date.now()*100+Math.floor(Math.random()*100)}
