// เช็คบิล หารบิล พิมพ์ใบเสร็จ
function billSheet(){const t=T();t.status='bill';save();
 const c=calc(t,S.cfg.disc);
 $('#sh').innerHTML=`<div class="row"><h2>เช็คบิล โต๊ะ ${t.id}</h2><button class="b" onclick="tableSheet()">กลับ</button></div>
 <div class="card">${t.items.filter(i=>!i.cx).map(i=>`<div class="tot"><span>${esc(i.name)} ×${i.qty}</span><span>${fmt(i.price*i.qty)}</span></div>`).join('')}</div>
 <div class="card"><div class="row"><span>ส่วนลด (%)</span><input type="number" style="width:90px" value="${S.cfg.disc}" onchange="S.cfg.disc=Math.max(0,+this.value||0);billSheet()"></div>
 <div class="tot m"><span>ค่าบริการ ${S.cfg.svc}%</span><span>${fmt(c.svc)}</span></div><div class="tot m"><span>ภาษี ${S.cfg.vat}%</span><span>${fmt(c.vat)}</span></div>
 <div class="tot g"><span>รวมทั้งหมด</span><span>฿${fmt(c.tot)}</span></div></div>
 <div class="card"><div class="row"><span>หารตามจำนวนท่าน</span><span class="q"><button class="b" onclick="sp(-1)">−</button><b id="spn">${Math.max(1,t.guests)}</b><button class="b" onclick="sp(1)">+</button></span></div>
 <div class="tot g"><span>คนละ</span><span id="spv">฿${fmt(Math.ceil(c.tot/Math.max(1,t.guests)*100)/100)}</span></div></div>
 <button class="b" style="width:100%;margin-bottom:8px" onclick="printBill()">🖨 พิมพ์ใบเสร็จ</button>
 <input id="mph" value="${esc(t.member||'')}" placeholder="เบอร์สมาชิก (สะสม 1 แต้ม/10 บาท)" style="margin-bottom:8px">
 <div class="row"><button class="b" style="flex:1" onclick="pay(1)">ชำระทั้งหมด ฿${fmt(c.tot)}</button><button class="b p" style="flex:1" onclick="pay(+$('#spn').textContent)">ชำระแบบหาร</button></div>`}
function sp(d){const n=Math.max(1,+$('#spn').textContent+d),c=calc(T(),S.cfg.disc);$('#spn').textContent=n;$('#spv').textContent='฿'+fmt(Math.ceil(c.tot/n*100)/100)}
function pay(n){const t=T(),c=calc(t,S.cfg.disc);const ph=(($('#mph')||{}).value||'').trim();let mp='';let dn={paid:Math.round(c.tot*100)/100};
 if(ph){let mm=S.members.find(x=>x.ph==ph);if(!mm){mm={ph,pts:0};S.members.push(mm)}const g=Math.floor(c.tot/10);mm.pts+=g;dn.pts=g;dn.total=mm.pts;mp=`<div class="tot m"><span>สมาชิก ${esc(ph)}</span><span>+${g} แต้ม (สะสม ${mm.pts})</span></div>`}
 S.sales.push({id:uid(),at:Date.now(),table:t.id,total:c.tot,items:t.items.filter(i=>!i.cx).map(i=>({name:i.base||i.name,qty:i.qty}))});
 const rows=t.items.filter(i=>!i.cx);
 $('#sh').innerHTML=`<div id="rc" class="card"><h3 style="text-align:center;margin:0">ใบเสร็จ</h3><p class="m" style="text-align:center">โต๊ะ ${t.id} · ${new Date().toLocaleString('th-TH')}</p>
 ${rows.map(i=>`<div class="tot"><span>${esc(i.name)} ×${i.qty}</span><span>${fmt(i.price*i.qty)}</span></div>`).join('')}
 <div class="tot m"><span>ส่วนลด</span><span>-${fmt(c.d)}</span></div><div class="tot m"><span>ค่าบริการ</span><span>${fmt(c.svc)}</span></div><div class="tot m"><span>ภาษี</span><span>${fmt(c.vat)}</span></div>
 <div class="tot g"><span>รวม</span><span>฿${fmt(c.tot)}</span></div>${n>1?`<div class="tot"><span>หาร ${n} คน</span><span>คนละ ฿${fmt(Math.ceil(c.tot/n*100)/100)}</span></div>`:''}${mp}</div>
 <div class="row"><button class="b" style="flex:1" onclick="try{window.print()}catch(e){alert('เปิดหน้านี้ในแท็บใหม่ของเบราว์เซอร์เพื่อพิมพ์')}">พิมพ์</button><button class="b p" style="flex:1" onclick="finish()">เสร็จสิ้น</button></div>`;
 t.items=[];t.status='free';t.guests=0;t.member='';t.cname='';dn.at=Date.now();t.done=dn;save()}
function printBill(){const t=T(),c=calc(t,S.cfg.disc),n=Math.max(1,+($('#spn')||{textContent:t.guests}).textContent||t.guests);
 const x=document.createElement('div');x.id='rcx';
 x.innerHTML=`<h3 style="text-align:center;margin:0">ใบเสร็จ / ใบแจ้งยอด</h3><p style="text-align:center;font-size:13px">โต๊ะ ${t.id} · ${t.guests} ท่าน · ${new Date().toLocaleString('th-TH')}</p>`+t.items.filter(i=>!i.cx).map(i=>`<div class="tot"><span>${esc(i.name)} ×${i.qty}</span><span>${fmt(i.price*i.qty)}</span></div>`).join('')+`<hr><div class="tot"><span>ยอดรวม</span><span>${fmt(c.sub)}</span></div><div class="tot"><span>ส่วนลด</span><span>-${fmt(c.d)}</span></div><div class="tot"><span>ค่าบริการ ${S.cfg.svc}%</span><span>${fmt(c.svc)}</span></div><div class="tot"><span>ภาษี ${S.cfg.vat}%</span><span>${fmt(c.vat)}</span></div><div class="tot g"><span>สุทธิ</span><span>฿${fmt(c.tot)}</span></div>`+(n>1?`<div class="tot"><span>หาร ${n} ท่าน</span><span>คนละ ฿${fmt(Math.ceil(c.tot/n*100)/100)}</span></div>`:'');
 document.body.appendChild(x);try{window.print()}catch(e){alert('เปิดหน้านี้ในแท็บใหม่ของเบราว์เซอร์เพื่อพิมพ์')}setTimeout(()=>x.remove(),500)}
function finish(){closeM()}
