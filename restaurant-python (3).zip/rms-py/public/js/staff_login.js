// เข้าสู่ระบบพนักงาน (PIN)
function login(){$('#nav').style.display='none';$('#app').innerHTML='<h2>เข้าสู่ระบบพนักงาน</h2><div class="card"><input id="pin" type="password" inputmode="numeric" placeholder="PIN"><button class="b p" style="margin-top:8px;width:100%" onclick="doLogin()">เข้าใช้งาน</button></div><p class="m" id="pe"></p>'}
async function doLogin(){const r=await fetch('/api/staff/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pin:$('#pin').value})});
 if(!r.ok){$('#pe').textContent='PIN ไม่ถูกต้อง';return}localStorage.setItem('tk',(await r.json()).token);location.reload()}
