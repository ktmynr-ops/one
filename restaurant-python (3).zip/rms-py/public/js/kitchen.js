// หน้าจอครัว
function vKitchen(){
 const all=[];S.tables.forEach(t=>t.items.forEach(i=>{if(!i.cx&&i.k!='done')all.push({...i,tb:t.id})}));all.sort((a,b)=>a.at-b.at);
 const mins=a=>Math.floor((Date.now()-a)/60000);
 return `<h2>หน้าจอครัว</h2>`+(all.map((i,n)=>`<div class="card"><div class="row"><div><b>#${n+1} ${esc(i.name)} ×${i.qty}</b><div class="m">โต๊ะ ${i.tb} · ${hm(i.at)} · สั่งมา ${mins(i.at)} นาที</div></div><span class="tag ${i.k=='wait'?'wt':'ok'}">${KS[i.k]}</span></div>
 <div style="margin-top:8px"><button class="b ${i.k=='wait'?'p':''}" onclick="kset(${i.tb},${i.id},'${i.k=='wait'?'cook':'done'}')">${i.k=='wait'?'เริ่มทำ':'ทำเสร็จ'}</button></div></div>`).join('')||'<p class="m">ไม่มีออเดอร์ค้าง</p>');
}
function kset(tb,id,k){const t=S.tables.find(x=>x.id==tb);t.items.find(i=>i.id==id).k=k;
 const a=t.items.filter(i=>!i.cx);if(a.length&&a.every(i=>i.k=='done')&&t.status=='busy')t.status='bill'; // ออเดอร์เสร็จทั้งหมด -> รอเช็คบิล
 render()}
setInterval(()=>{if(S.tab=='kitchen'&&!$('#md').classList.contains('on'))render()},30000);
