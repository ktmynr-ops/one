// โต๊ะ แผนผัง ออเดอร์ QR
function vTables(){
 const free=S.tables.filter(t=>t.status=='free').length;
 S.tables.forEach((t,i)=>{if(t.x==null){t.x=14+(i%4)*24;t.y=16+Math.floor(i/4)*30}});
 const seg=(k,l)=>`<button class="b ${S.view==k?'p':''}" onclick="S.view='${k}';S.edit=false;render()">${l}</button>`;
 let body;
 if(S.view=='list'){
  body='<div class="grid">'+S.tables.map(t=>{const [l,c]=ST[t.status];const n=t.items.filter(i=>!i.cx).length;
  return `<div class="card tb ${t.status}" onclick="openTable(${t.id})"><b>โต๊ะ ${t.id}</b><span class="tag ${c}">${l}</span><div class="m">👥 ${t.guests}/${t.seats} ที่นั่ง</div>${n?`<div class="m">${n} รายการ</div>`:''}</div>`}).join('')+'</div>';
 }else{
  body=`<div class="plan ${S.edit?'ed':''}" id="plan">`+S.tables.map(t=>{const n=t.items.filter(i=>!i.cx).length;
  return `<div class="pt ${t.status}" style="left:${t.x}%;top:${t.y}%" onpointerdown="drag(event,${t.id})" onclick="if(!S.edit)openTable(${t.id})"><b>${t.id}</b><span>${ST[t.status][0]}</span><span class="m">👥${t.guests}/${t.seats}</span></div>`}).join('')+'</div>'
  +`<div class="leg"><span><i style="background:var(--ok)"></i>ว่าง</span><span><i style="background:var(--warn)"></i>มีลูกค้า</span><span><i style="background:var(--wait)"></i>รอเช็คบิล</span></div>`
  +`<div class="row"><span class="m">${S.edit?'ลากโต๊ะเพื่อจัดตำแหน่ง':'แตะโต๊ะเพื่อดูออเดอร์'}</span><button class="b ${S.edit?'p':''}" onclick="S.edit=!S.edit;render()">${S.edit?'บันทึกผัง':'จัดผังโต๊ะ'}</button></div>`;
 }
 return `<div class="row"><h2>โต๊ะ</h2><span class="m">ว่าง ${free} / เต็ม ${S.tables.length-free}</span></div>
 <div class="row" style="justify-content:flex-start;margin-bottom:10px">${seg('plan','แผนผัง')}${seg('list','รายการ')}</div>${body}
 <div class="row" style="margin-top:12px"><button class="b" onclick="addTable()">+ เพิ่มโต๊ะ</button>${S.tables.length&&S.tables[S.tables.length-1].status=='free'&&S.tables[S.tables.length-1].id>1?'<button class="b d" onclick="delTable()">ลบโต๊ะล่าสุด</button>':''}</div>`;
}
function drag(e,id){if(!S.edit)return;const el=e.currentTarget,r=$('#plan').getBoundingClientRect(),t=S.tables.find(x=>x.id==id);
 el.setPointerCapture(e.pointerId);
 el.onpointermove=ev=>{t.x=Math.round(Math.min(94,Math.max(6,(ev.clientX-r.left)/r.width*100)));t.y=Math.round(Math.min(92,Math.max(8,(ev.clientY-r.top)/r.height*100)));el.style.left=t.x+'%';el.style.top=t.y+'%'};
 el.onpointerup=()=>{el.onpointermove=null;save()}}
function delTable(){S.tables.pop();render()}
function addTable(){const sc=+prompt('โต๊ะนี้นั่งได้กี่คน','4')||4;S.tables.push({id:S.tables.length+1,status:'free',items:[],seats:sc,guests:0});render()}
function openTable(id){S.open=id;tableSheet();$('#md').classList.add('on')}
function tableSheet(){
 const t=T();const act=t.items.filter(i=>!i.cx).sort((a,b)=>a.at-b.at);
 if(t.status=='free'&&!t.guests){$('#sh').innerHTML=`<div class="row"><h2>โต๊ะ ${t.id}</h2><button class="b" onclick="closeM()">ปิด</button></div><div class="card"><div class="row"><span>โต๊ะนี้นั่งได้ ${t.seats} คน</span><span class="q"><button class="b" onclick="st(-1)">−</button><button class="b" onclick="st(1)">+</button></span></div></div><b>ลูกค้ามากี่ท่าน?</b><div class="grid" style="margin-top:8px">`+Array.from({length:t.seats+2},(_,i)=>`<button class="b p" ${i+1>t.seats?'disabled':''} onclick="gset(${i+1})">${i+1}</button>`).join('')+'</div><p class="m">ถ้ามาเกิน '+t.seats+' ท่าน กดไม่ได้ ให้เปลี่ยนไปโต๊ะที่ใหญ่กว่า:</p>'+(S.tables.filter(f=>f.status=='free'&&f.seats>t.seats).map(f=>`<button class="b" style="margin:2px" onclick="openTable(${f.id})">โต๊ะ ${f.id} (${f.seats} ที่)</button>`).join('')||'<p class="m">ไม่มีโต๊ะว่างที่ใหญ่กว่านี้</p>');return}
 $('#sh').innerHTML=`<div class="row"><h2>โต๊ะ ${t.id}</h2><button class="b" onclick="closeM()">ปิด</button></div>
 <div class="row" style="margin-bottom:8px"><span class="tag ${ST[t.status][1]}">${ST[t.status][0]}</span>
 <span><button class="b" onclick="mv()">ย้าย</button> <button class="b" onclick="mg()">รวมโต๊ะ</button> ${!act.length?'<button class="b d" onclick="clr()">เคลียร์โต๊ะ</button> ':''}${t.status=='busy'&&act.length?'<button class="b p" onclick="billSheet()">เช็คบิล</button>':''}${t.status=='bill'?'<button class="b p" onclick="billSheet()">เช็คบิล</button>':''}</span></div>
 <div class="card row"><span>👥 ${t.guests}/${t.seats} ท่าน${t.cname?' · '+esc(t.cname):''}</span><span class="q"><button class="b" onclick="gu(-1)">−</button><button class="b" onclick="gu(1)">+</button><button class="b" onclick="qr()">QR สั่งเอง</button></span></div>
 <b>รายการสั่ง</b>
 ${act.map(i=>`<div class="card"><div class="row"><div>${esc(i.name)} ×${i.qty}<div class="m">${hm(i.at)} · ฿${fmt(i.price*i.qty)} · ${KS[i.k]}</div></div><span class="q"><button class="b" onclick="chg(${i.id},-1)">−</button><button class="b" onclick="chg(${i.id},1)">+</button><button class="b d" onclick="cxl(${i.id})">ยกเลิก</button></span></div></div>`).join('')||'<p class="m">ยังไม่มีรายการ เลือกเมนูด้านล่าง</p>'}
 <b>เพิ่มเมนู</b><div style="margin-top:6px">`+menuSorted().map(m=>`<div class="card"><div class="row"><span>${pic(m)} ${esc(m.name)} ${bs(m)}<span class="m">฿${fmt(m.price)}</span></span>${stockTag(m)}<button class="b p" ${m.stock<=0||!can(m,1)?'disabled':''} onclick="order(${m.id})">สั่ง</button></div></div>`).join('')+'</div>';
}
function order(mid){const m=S.menu.find(x=>x.id==mid);if(m.stock<=0||!can(m,1))return;choose(mid)}
function add(mid,o){const t=T(),m=S.menu.find(x=>x.id==mid);if(m.stock<=0||!can(m,1))return alert('สินค้าหรือวัตถุดิบหมด');
 const L=o.labels,key=mid+':'+L.join(),ex=t.items.find(i=>i.key==key&&i.k=='wait'&&!i.cx);
 m.stock--;use(m,1);
 if(ex)ex.qty++;else t.items.push({id:uid(),mid,key,base:m.name,name:m.name+(L.length?' ('+L.join(', ')+')':''),price:m.price+o.extra,qty:1,k:'wait',at:Date.now(),cx:0});
 if(t.status!='busy')t.status='busy';save();refresh()}
function chg(iid,d){const t=T(),i=t.items.find(x=>x.id==iid),m=S.menu.find(x=>x.id==i.mid);
 if(d>0){if(m&&(m.stock<=0||!can(m,1)))return alert('สินค้าหมด');i.qty++;if(m){m.stock--;use(m,1)}}
 else{if(i.qty<=1)return cxl(iid);i.qty--;if(m){m.stock++;use(m,-1)}}save();refresh()}
function cxl(iid){const t=T(),i=t.items.find(x=>x.id==iid),m=S.menu.find(x=>x.id==i.mid);
 if(m){m.stock+=i.qty;use(m,-i.qty)}i.cx=1;save();refresh()}
function mv(){const to=prompt('ย้ายไปโต๊ะหมายเลข (ต้องเป็นโต๊ะว่าง)');const d=S.tables.find(x=>x.id==+to);
 if(!d||d.status!='free')return alert('โต๊ะปลายทางไม่ว่าง');if(d.seats<t.guests)return alert('โต๊ะปลายทางที่นั่งไม่พอ');const t=T();d.items=t.items;d.status=t.status;d.guests=t.guests;t.guests=0;t.items=[];t.status='free';S.open=d.id;tableSheet();save()}
function gset(n){const t=T();if(n>t.seats)return alert('เกินจำนวนที่นั่ง กรุณาเปลี่ยนโต๊ะ');t.done=null;t.guests=n;t.status='busy';if(QT){const a=$('#cn'),b=$('#cp');if(a&&a.value.trim())t.cname=a.value.trim();if(b&&b.value.trim())t.member=b.value.trim()}save();refresh()}
function gu(d){const t=T();if(t.guests+d>t.seats)return alert('เกินจำนวนที่นั่ง กรุณาเปลี่ยนโต๊ะ');t.guests=Math.max(1,t.guests+d);tableSheet();save()}
function st(d){const t=T();t.seats=Math.max(1,t.seats+d);tableSheet();save()}
function clr(){const t=T();t.items=[];t.status='free';t.guests=0;t.member='';t.cname='';tableSheet();save()}
function mg(){const to=prompt('รวมบิลกับโต๊ะหมายเลข (ต้องมีลูกค้า)'),d=S.tables.find(x=>x.id==+to),t=T();
 if(!d||d==t||d.status=='free')return alert('เลือกโต๊ะที่มีลูกค้า');
 t.items=t.items.concat(d.items);t.guests+=d.guests;t.seats+=d.seats;d.items=[];d.guests=0;d.status='free';tableSheet();save()}
async function qr(){const t=T();let u='';
 try{const r=await fetch('/api/staff/table-link/'+t.id,{headers:{Authorization:'Bearer '+TK}});u=(await r.json()).url}catch(e){return alert('สร้าง QR ไม่สำเร็จ')}
 const priv=/^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(new URL(u).hostname);
 $('#sh').innerHTML=`<div class="row"><h2>QR โต๊ะ ${t.id}</h2><button class="b" onclick="tableSheet()">กลับ</button></div><div class="card" style="text-align:center"><img alt="QR โต๊ะ ${t.id}" src="/api/staff/table-qr/${t.id}.png?t=${TK}&_=${Date.now()}" style="width:230px;height:230px;background:#fff;padding:8px;border-radius:8px"><p class="m">ลูกค้าสแกนเพื่อสั่งอาหารเอง</p><a href="${u}" target="_blank" style="word-break:break-all;font-size:12px">${u}</a></div>`+(priv?'<div class="card wt"><b>ลิงก์นี้ใช้ได้เฉพาะมือถือที่ต่อเครือข่ายเดียวกัน</b><div class="m">ถ้าลูกค้าสแกนไม่ได้ ให้รัน <code>python server.py --tunnel</code> แล้วเปิดหน้านี้ผ่านลิงก์ https ที่ได้</div></div>':'')}
