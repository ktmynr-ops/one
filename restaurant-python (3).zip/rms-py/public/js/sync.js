// ซิงค์กับเซิร์ฟเวอร์ (WebSocket) และเข้าสู่ระบบ
function save(){if(READY)push()}
const TK=localStorage.getItem('tk')||'';
let SNAP={},READY=false,sock=null;
const INC={menu:['stock'],ings:['qty'],members:['pts']};
const cl=o=>JSON.parse(JSON.stringify(o));
function flat(st){const m={};
 st.menu.forEach(x=>m['menu:'+x.id]=x);st.ings.forEach(x=>m['ings:'+x.id]=x);st.queue.forEach(x=>m['queue:'+x.id]=x);
 st.members.forEach(x=>m['members:'+x.ph]=x);st.sales.forEach(x=>m['sales:'+x.id]=x);
 st.tables.forEach(t=>{const {items,...r}=t;m['tables:'+t.id]=r;items.forEach(i=>m['items:'+t.id+':'+i.id]=i)});
 m['meta:m']={qn:st.qn||0,cfg:st.cfg};return m}
function unflat(m,st){const g=p=>Object.keys(m).filter(k=>k.startsWith(p+':')).map(k=>cl(m[k]));
 st.menu=g('menu').sort((a,b)=>a.id-b.id);st.ings=g('ings').sort((a,b)=>a.id-b.id);st.queue=g('queue').sort((a,b)=>a.no-b.no);
 st.members=g('members');st.sales=g('sales').sort((a,b)=>a.at-b.at);
 st.tables=g('tables').sort((a,b)=>a.id-b.id).map(t=>({...t,items:[]}));
 Object.keys(m).filter(k=>k.startsWith('items:')).forEach(k=>{const t=st.tables.find(x=>x.id==k.split(':')[1]);if(t)t.items.push(cl(m[k]))});
 st.tables.forEach(t=>t.items.sort((a,b)=>a.id-b.id));
 const mt=m['meta:m'];if(mt){st.qn=mt.qn;st.cfg=cl(mt.cfg)}}
function applyOps(m,ops){for(const o of ops){
 if(o.op=='put')m[o.k]=o.d;else if(o.op=='del')delete m[o.k];
 else if(!m[o.k])continue;
 else if(o.op=='patch'){for(const f in o.d)o.d[f]===null?delete m[o.k][f]:m[o.k][f]=o.d[f]}
 else if(o.op=='inc')m[o.k][o.f]=Math.max(0,(m[o.k][o.f]||0)+o.by)}}
function diff(){const cur=flat(S),ops=[];
 for(const k in cur){const a=cur[k],b=SNAP[k];if(!b){ops.push({op:'put',k,d:cl(a)});continue}
  const ch={},col=k.split(':')[0];
  for(const f in a){if(JSON.stringify(a[f])===JSON.stringify(b[f]))continue;
   if((INC[col]||[]).includes(f)&&typeof a[f]=='number'&&typeof b[f]=='number')ops.push({op:'inc',k,f,by:a[f]-b[f]});else ch[f]=a[f]}
  for(const f in b)if(!(f in a))ch[f]=null;
  if(Object.keys(ch).length)ops.push({op:'patch',k,d:cl(ch)})}
 for(const k in SNAP)if(!(k in cur))ops.push({op:'del',k});
 return ops}
function push(){const ops=diff();if(!ops.length)return;SNAP=cl(flat(S));sock.emit('ops',ops)}
function after(){render();const h=($('#sh').querySelector('h2')||{}).textContent;
 if(!QT&&$('#md').classList.contains('on')&&h=='โต๊ะ '+S.open)tableSheet()}
function start(){sock=io({auth:{token:TK,table:QT||'',key:QK}});
 sock.on('connect_error',()=>{if(QT)custError();else{localStorage.removeItem('tk');login()}});
 sock.on('init',m=>{
  if(!Object.keys(m).length&&!QT){SNAP=cl(flat(S));sock.emit('ops',Object.keys(SNAP).map(k=>({op:'put',k,d:SNAP[k]})))}
  else{SNAP=m;unflat(SNAP,S)}
  READY=true;if(QT)S.open=+QT;after()});
 sock.on('ops',ops=>{applyOps(SNAP,ops);unflat(SNAP,S);after()})}
