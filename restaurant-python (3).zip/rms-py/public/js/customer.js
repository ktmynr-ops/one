// หน้าลูกค้า: สแกน QR -> ใส่ชื่อ/เบอร์สมาชิก (ไม่บังคับ) -> เลือกจำนวนท่าน -> สั่งอาหาร -> รับแต้มแบบเรียลไทม์
let seenDone=0;
function custError(){$('#nav').style.display='none';$('#app').innerHTML='<h2>QR ไม่ถูกต้อง</h2><p class="m">กรุณาสแกน QR ที่โต๊ะอีกครั้ง หรือเรียกพนักงาน</p>'}
function cust(){const t=T();$('#nav').style.display='none';if(!t){$('#app').innerHTML='<p>ไม่พบโต๊ะนี้</p>';return}
 let h=`<h2>โต๊ะ ${t.id}</h2>`;
 if(!t.guests&&t.done&&!seenDone){const d=t.done;
  h+=`<div class="card"><b>ขอบคุณที่ใช้บริการ 🙏</b><div class="m" style="margin:6px 0">ยอดชำระ ฿${fmt(d.paid)}</div>`+(d.pts!=null?`<div style="font-size:20px;font-weight:600">ได้รับ +${d.pts} แต้ม</div><div class="m">แต้มสะสมรวม ${d.total} แต้ม</div>`:'<div class="m">ใส่เบอร์สมาชิกครั้งหน้าเพื่อสะสมแต้ม</div>')+`<button class="b p" style="margin-top:10px" onclick="seenDone=1;cust()">สั่งอาหารใหม่</button></div>`}
 else if(!t.guests)h+=`<div class="card"><b>ยินดีต้อนรับ</b><input id="cn" placeholder="ชื่อของคุณ (ไม่บังคับ)" style="margin:8px 0"><input id="cp" inputmode="numeric" placeholder="เบอร์สมาชิกเพื่อสะสมแต้ม (ไม่บังคับ)"><div class="m" style="margin:10px 0 6px">มากี่ท่าน? (โต๊ะนี้นั่งได้ ${t.seats} คน ถ้ามาเกินกรุณาแจ้งพนักงานเพื่อเปลี่ยนโต๊ะ)</div><div class="grid">`+Array.from({length:t.seats},(_,i)=>`<button class="b p" onclick="gset(${i+1})">${i+1}</button>`).join('')+'</div></div>';
 else{const act=t.items.filter(i=>!i.cx).sort((a,b)=>a.at-b.at);
  h+=`<div class="m">${t.cname?'สวัสดีคุณ '+esc(t.cname)+' · ':''}👥 ${t.guests} ท่าน</div>`+(t.status=='bill'?'<div class="card wt"><b>รอเช็คบิล</b> ออเดอร์เสร็จครบแล้ว กรุณารอพนักงานนำบิลมา</div>':'')+'<b>ออเดอร์ของคุณ</b>'+(act.map(i=>`<div class="card row"><span>${esc(i.name)} ×${i.qty}<div class="m">${hm(i.at)} · ${KS[i.k]}</div></span>${i.k=='wait'?`<button class="b d" onclick="cxl(${i.id})">ยกเลิก</button>`:''}</div>`).join('')||'<p class="m">ยังไม่ได้สั่ง</p>')
  +`<b>เมนู</b><div style="margin-top:6px">`+menuSorted().map(m=>`<div class="card"><div class="row"><span>${pic(m)} ${esc(m.name)} ${bs(m)}<span class="m">฿${fmt(m.price)}</span></span>${stockTag(m)}<button class="b p" ${m.stock<=0||!can(m,1)?'disabled':''} onclick="order(${m.id})">สั่ง</button></div></div>`).join('')+'</div>'}
 $('#app').innerHTML=h}
