// รายงานและสมาชิก
function vReport(){
 const d=new Date().toDateString(),td=S.sales.filter(s=>new Date(s.at).toDateString()==d);
 const sum=td.reduce((a,s)=>a+s.total,0),cnt={};
 td.forEach(s=>s.items.forEach(i=>cnt[i.name]=(cnt[i.name]||0)+i.qty));
 const top=Object.entries(cnt).sort((a,b)=>b[1]-a[1]),mx=top[0]?top[0][1]:1;
 return `<h2>รายงานวันนี้</h2><div class="card"><div class="m">ยอดขายรวม</div><div style="font-size:30px;font-weight:600">฿${fmt(sum)}</div><div class="m">${td.length} บิล</div></div>
 <div class="card"><b>เมนูขายดี</b>`+(top.map(([n,q])=>`<div style="margin-top:8px"><div class="bar"><span>${esc(n)}</span><span>${q} จาน</span></div><div style="height:6px;background:var(--line);border-radius:4px"><div style="height:6px;width:${q/mx*100}%;background:var(--main);border-radius:4px"></div></div></div>`).join('')||'<p class="m">ยังไม่มียอดขาย</p>')+`</div>
 <div class="card"><b>สมาชิก</b>${S.members.map(m=>`<div class="tot"><span>${esc(m.ph)}</span><span>${m.pts} แต้ม</span></div>`).join('')||'<p class="m">ยังไม่มีสมาชิก</p>'}</div>
 <button class="b d" onclick="if(confirm('ล้างข้อมูลทั้งหมด?')){localStorage.removeItem('rms');location.reload()}">รีเซ็ตข้อมูล</button>`;
}
