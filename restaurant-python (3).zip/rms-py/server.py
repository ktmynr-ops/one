"""จุดเริ่มต้น: รันไฟล์นี้  ->  python server.py"""
import os, socket, sys
from rms.app import create_app
from rms import tunnel
from rms.config import PIN, PORT


def lan_ip():
    try:
        x = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        x.connect(("8.8.8.8", 80))
        return x.getsockname()[0]
    except OSError:
        return None


if __name__ == "__main__":
    app, socketio = create_app()
    print(f"เปิดที่ http://localhost:{PORT}   (PIN พนักงาน: {PIN})")
    if "--tunnel" in sys.argv or os.environ.get("TUNNEL") == "1":
        tunnel.start(PORT)
    ip = lan_ip()
    if ip:
        print(f"มือถือในวง Wi-Fi เดียวกันใช้: http://{ip}:{PORT}")
    socketio.run(app, host="0.0.0.0", port=PORT, allow_unsafe_werkzeug=True)
