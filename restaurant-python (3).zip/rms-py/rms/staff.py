"""API ฝั่งพนักงาน: เข้าสู่ระบบด้วย PIN, อัปโหลดรูป, สร้างกุญแจ QR ประจำโต๊ะ"""
import base64, os, re, time
from flask import Blueprint, jsonify, request, send_file
from . import auth, qr
from . import config
from .config import TOKEN, UPLOADS

bp = Blueprint("staff", __name__, url_prefix="/api/staff")


def _is_staff():
    return request.headers.get("Authorization") == "Bearer " + TOKEN


@bp.post("/login")
def login():
    pin = (request.get_json(silent=True) or {}).get("pin")
    r = auth.check_pin(request.remote_addr, pin)
    if r == "ok":
        return jsonify({"token": TOKEN})
    return jsonify({}), (429 if r == "locked" else 401)


@bp.get("/table-link/<int:table>")
def table_link(table):
    if not _is_staff():
        return jsonify({}), 401
    return jsonify({"url": qr.table_url(request, table)})


@bp.get("/table-qr/<int:table>.png")
def table_qr(table):
    """รูป QR ของโต๊ะ (สร้างฝั่งเซิร์ฟเวอร์) ใช้ ?t=<token พนักงาน> เพื่อให้ใส่ใน <img> ได้"""
    if request.args.get("t") != TOKEN:
        return jsonify({}), 401
    return send_file(qr.png(qr.table_url(request, table)), mimetype="image/png")


@bp.post("/upload")
def upload():
    if not _is_staff():
        return jsonify({}), 401
    data = (request.get_json(silent=True) or {}).get("data", "")
    m = re.match(r"^data:image/(jpeg|png|webp);base64,(.+)$", data, re.S)
    if not m:
        return jsonify({"error": "invalid image"}), 400
    ext = "jpg" if m.group(1) == "jpeg" else m.group(1)
    name = f"{int(time.time() * 1000)}-{os.urandom(3).hex()}.{ext}"
    with open(os.path.join(UPLOADS, name), "wb") as f:
        f.write(base64.b64decode(m.group(2)))
    return jsonify({"url": "/uploads/" + name})
