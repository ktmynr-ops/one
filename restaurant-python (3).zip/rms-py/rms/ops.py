"""คำสั่งย่อยที่หน้าเว็บส่งมา: put / patch / inc / del"""


def valid(o):
    if not isinstance(o, dict) or not isinstance(o.get("k"), str):
        return False
    op = o.get("op")
    if op in ("put", "patch"):
        return isinstance(o.get("d"), dict)
    if op == "inc":
        by = o.get("by")
        return isinstance(o.get("f"), str) and isinstance(by, (int, float)) and not isinstance(by, bool)
    return op == "del"


def apply_ops(m, ops):
    for o in ops:
        op, k = o["op"], o["k"]
        if op == "put":
            m[k] = o["d"]
        elif op == "del":
            m.pop(k, None)
        elif k not in m:
            continue
        elif op == "patch":
            for f, v in o["d"].items():
                if v is None:
                    m[k].pop(f, None)
                else:
                    m[k][f] = v
        elif op == "inc":  # สต๊อกเป็นส่วนต่าง (+/-) ไม่ทับกัน
            m[k][o["f"]] = max(0, (m[k].get(o["f"]) or 0) + o["by"])
