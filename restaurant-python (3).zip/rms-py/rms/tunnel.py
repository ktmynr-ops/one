"""เปิด Cloudflare Tunnel อัตโนมัติ เพื่อให้ลูกค้าสแกน QR ผ่านเน็ตมือถือได้"""
import atexit, re, shutil, subprocess, threading
from . import config


def start(port):
    exe = shutil.which("cloudflared")
    if not exe:
        print("ไม่พบ cloudflared ติดตั้งด้วย: winget install --id Cloudflare.cloudflared (แล้วเปิด Terminal ใหม่)")
        return
    p = subprocess.Popen([exe, "tunnel", "--url", f"http://localhost:{port}"], stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="ignore")
    atexit.register(p.terminate)

    def reader():
        for line in p.stdout:
            m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
            if m and not config.PUBLIC_URL:
                config.PUBLIC_URL = m.group(0)
                print("ลิงก์สาธารณะสำหรับลูกค้า:", config.PUBLIC_URL, "(เปิดหน้า /staff ที่ลิงก์นี้ได้เช่นกัน)")

    threading.Thread(target=reader, daemon=True).start()
