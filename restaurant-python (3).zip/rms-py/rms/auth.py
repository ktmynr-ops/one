"""สิทธิ์: พนักงาน (PIN) กับลูกค้า (สแกน QR ประจำโต๊ะ)"""
import re, time
import hashlib, hmac
from . import store
from .config import PIN, SECRET

SESS = {}    # sid -> {"role": "staff"|"cust", "table": "3"}
_FAILS = {}  # ip -> (จำนวนครั้งที่ผิด, เวลาล่าสุด)


def check_pin(ip, pin):
    n, t = _FAILS.get(ip, (0, 0))
    if n >= 10 and time.time() - t < 60:
        return "locked"
    if pin == PIN:
        _FAILS.pop(ip, None)
        return "ok"
    _FAILS[ip] = (n + 1, time.time())
    return "bad"


def table_key(table):
    """กุญแจประจำโต๊ะ ฝังใน QR ป้องกันการเดาเลขโต๊ะ"""
    return hmac.new(SECRET.encode(), ("table:" + str(table)).encode(), hashlib.sha256).hexdigest()[:16]


def verify_table(table, key):
    return hmac.compare_digest(table_key(table), str(key or ""))


def visible(s, k):
    """ลูกค้าเห็นเฉพาะเมนู วัตถุดิบ และข้อมูลโต๊ะตัวเอง"""
    return (s["role"] == "staff" or re.match(r"^(menu|ings|meta):", k) is not None
            or k == "tables:" + s["table"] or k.startswith("items:" + s["table"] + ":"))


def allowed(s, o):
    """ลูกค้าแก้ได้เฉพาะออเดอร์/สถานะโต๊ะตัวเอง และปรับสต๊อก"""
    if s["role"] == "staff":
        return True
    t, k = s["table"], o["k"]
    if o["op"] == "inc":
        return (k.startswith("menu:") and o["f"] == "stock") or (k.startswith("ings:") and o["f"] == "qty")
    if k.startswith("items:" + t + ":"):
        return True
    if k == "tables:" + t:
        if o["op"] != "patch" or not all(f in ("guests", "status", "cname", "member", "done") for f in o["d"]):
            return False
        g = o["d"].get("guests")
        if g is not None:  # ห้ามนั่งเกินจำนวนที่นั่ง
            seats = (store.MEM.get(k) or {}).get("seats", 0)
            return isinstance(g, int) and not isinstance(g, bool) and 0 <= g <= seats
        return True
    return False
