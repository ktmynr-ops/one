"""WebSocket: ส่งข้อมูลเริ่มต้น รับคำสั่งย่อย และกระจายให้เครื่องอื่นแบบเรียลไทม์"""
import re
from flask import request
from flask_socketio import emit
from . import auth, store
from .config import TOKEN
from .ops import apply_ops, valid


def register(socketio):
    @socketio.on("connect")
    def on_connect(a):
        a = a or {}
        if a.get("token") == TOKEN:
            s = {"role": "staff", "table": ""}
        elif re.fullmatch(r"\d+", str(a.get("table") or "")) and auth.verify_table(a["table"], a.get("key")):
            s = {"role": "cust", "table": str(a["table"])}
        else:
            return False  # ปฏิเสธการเชื่อมต่อ
        auth.SESS[request.sid] = s
        with store.LOCK:
            emit("init", {k: v for k, v in store.MEM.items() if auth.visible(s, k)})

    @socketio.on("disconnect")
    def on_disconnect(*_):
        auth.SESS.pop(request.sid, None)

    @socketio.on("ops")
    def on_ops(ops):
        s = auth.SESS.get(request.sid)
        if not s or not isinstance(ops, list):
            return
        ops = [o for o in ops if valid(o) and auth.allowed(s, o)]
        if not ops:
            return
        with store.LOCK:
            apply_ops(store.MEM, ops)
            store.persist({o["k"] for o in ops})
        for sid, other in list(auth.SESS.items()):
            if sid == request.sid:
                continue
            v = [o for o in ops if auth.visible(other, o["k"])]
            if v:
                socketio.emit("ops", v, to=sid)
