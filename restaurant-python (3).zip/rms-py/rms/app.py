"""ประกอบแอป: สร้าง Flask + Socket.IO แล้วลงทะเบียนโมดูลต่างๆ"""
from flask import Flask
from flask_socketio import SocketIO
from . import customer, pages, sockets, staff


def create_app():
    app = Flask(__name__, static_folder=None)
    for m in (pages, staff, customer):
        app.register_blueprint(m.bp)
    socketio = SocketIO(app, async_mode="threading", max_http_buffer_size=5_000_000)
    sockets.register(socketio)
    return app, socketio
