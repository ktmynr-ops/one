"""ค่าตั้งต้นของระบบ"""
import hashlib, hmac, os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = int(os.environ.get("PORT", 3000))
PIN = os.environ.get("STAFF_PIN", "1234")  # เปลี่ยน PIN: STAFF_PIN=5678
SECRET = os.environ.get("RMS_SECRET", PIN + "-rms")  # ใช้เซ็น QR ประจำโต๊ะ
TOKEN = hmac.new(PIN.encode(), b"rms-staff", hashlib.sha256).hexdigest()
PUBLIC = os.path.join(BASE, "public")
UPLOADS = os.path.join(BASE, "uploads")
DB_PATH = os.path.join(BASE, "rms.db")
PUBLIC_URL = os.environ.get("PUBLIC_URL", "")  # ลิงก์สาธารณะสำหรับ QR (ถ้ามี)
os.makedirs(UPLOADS, exist_ok=True)
