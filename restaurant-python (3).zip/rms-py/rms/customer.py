"""API ฝั่งลูกค้า: ตรวจว่า QR ประจำโต๊ะถูกต้องก่อนเข้าหน้าสั่งอาหาร"""
from flask import Blueprint, jsonify, request
from . import auth

bp = Blueprint("customer", __name__, url_prefix="/api/customer")


@bp.get("/check")
def check():
    ok = auth.verify_table(request.args.get("table", ""), request.args.get("k", ""))
    return jsonify({"ok": ok}), (200 if ok else 403)
