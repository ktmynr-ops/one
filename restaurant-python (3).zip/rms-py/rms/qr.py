"""QR สั่งอาหารประจำโต๊ะ (แนวทางเดียวกับโปรเจกต์ rest.zip)
- สร้างรูป QR ฝั่งเซิร์ฟเวอร์ด้วยไลบรารี qrcode (ไม่พึ่ง JavaScript/CDN)
- หาลิงก์ฐานที่มือถือเข้าถึงได้: PUBLIC_URL > โดเมน/โฮสต์ที่เปิดอยู่ > IP ของเครื่อง (ถ้าเปิดผ่าน localhost)
"""
import io, socket
from urllib.parse import urlparse
from . import auth, config

_LOCAL = {"127.0.0.1", "localhost", "0.0.0.0", "::1"}


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        if ip and not ip.startswith("127."):
            return ip
    except OSError:
        pass
    finally:
        s.close()
    return "127.0.0.1"


def base_url(request):
    if config.PUBLIC_URL:
        return config.PUBLIC_URL.rstrip("/")
    host = (request.host or "").split(":")[0].lower()
    if host not in _LOCAL:
        return request.host_url.rstrip("/")
    port = urlparse(request.host_url).port
    return f"http://{lan_ip()}" + (f":{port}" if port else "")


def table_url(request, table):
    return f"{base_url(request)}/c?table={int(table)}&k={auth.table_key(table)}"


def png(url):
    import qrcode
    buf = io.BytesIO()
    qrcode.make(url, box_size=8, border=2).save(buf, format="PNG")
    buf.seek(0)
    return buf
