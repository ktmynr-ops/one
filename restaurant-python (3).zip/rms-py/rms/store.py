"""ที่เก็บข้อมูล: SQLite 1 แถวต่อ 1 รายการ + แคชในหน่วยความจำ (MEM)"""
import json, sqlite3, threading
from .config import DB_PATH

_db = sqlite3.connect(DB_PATH, check_same_thread=False)
_db.execute("CREATE TABLE IF NOT EXISTS ent (k TEXT PRIMARY KEY, v TEXT NOT NULL)")
_db.commit()

MEM = {k: json.loads(v) for k, v in _db.execute("SELECT k, v FROM ent")}
LOCK = threading.Lock()


def persist(keys):
    """บันทึกทุกการเปลี่ยนแปลงของคำสั่งชุดเดียวใน transaction เดียว"""
    with _db:
        for k in keys:
            if k in MEM:
                _db.execute("INSERT INTO ent(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                            (k, json.dumps(MEM[k], ensure_ascii=False)))
            else:
                _db.execute("DELETE FROM ent WHERE k=?", (k,))
