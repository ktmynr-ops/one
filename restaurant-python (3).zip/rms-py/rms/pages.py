"""หน้าเว็บและไฟล์ static: / (เลือกบทบาท)  /staff (พนักงาน)  /c (ลูกค้า สแกน QR)"""
import os
from flask import Blueprint, send_from_directory
from .config import PUBLIC, UPLOADS

bp = Blueprint("pages", __name__)


def _page(name):
    return send_from_directory(PUBLIC, name)


@bp.get("/")
def index():
    return _page("index.html")


@bp.get("/staff")
def staff():
    return _page("staff.html")


@bp.get("/c")
def customer():
    return _page("customer.html")


@bp.get("/js/<path:name>")
def js(name):
    return send_from_directory(os.path.join(PUBLIC, "js"), name)


@bp.get("/css/<path:name>")
def css(name):
    return send_from_directory(os.path.join(PUBLIC, "css"), name)


@bp.get("/uploads/<path:name>")
def uploads(name):
    return send_from_directory(UPLOADS, name)
